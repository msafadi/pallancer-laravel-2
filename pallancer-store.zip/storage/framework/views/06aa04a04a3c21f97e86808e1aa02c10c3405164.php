<?php if(isset($title)): ?>
<div class="alert alert-<?php echo e($type ?? 'info'); ?>">
    <h4><?php echo e($title); ?></h4>
    <p class="fs-5"><?php echo e($slot); ?></p>
    <?php echo e($actions); ?>

    <?php echo e($url); ?>

</div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get('error')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('warning')): ?>
<div class="alert alert-warning">
    <?php echo e(session()->get('warning')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('info')): ?>
<div class="alert alert-info">
    <?php echo e(session()->get('info')); ?>

</div>
<?php endif; ?><?php /**PATH E:\PalLancer Laravel 02\pallancer-store\resources\views/components/alert.blade.php ENDPATH**/ ?>