<?php if (isset($component)) { $__componentOriginal68fd1716d3649640b85d625349a99a37b7434812 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DashboardLayout::class, ['title' => 'Roles','subtitle' => 'Sub title']); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    <div class="table-toolbar mb-3">
        <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-info">Create</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Abilities</th>
                <th>Created At</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($role->id); ?></td>
                <td><a href="<?php echo e(route('admin.roles.edit', $role->id)); ?>"><?php echo e($role->name); ?></a></td>
                <td><?php echo e(count($role->abilities)); ?></td>
                <td><?php echo e($role->created_at); ?></td>
                <td>
                    <form action="<?php echo e(route('admin.roles.destroy', $role->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

 <?php if (isset($__componentOriginal68fd1716d3649640b85d625349a99a37b7434812)): ?>
<?php $component = $__componentOriginal68fd1716d3649640b85d625349a99a37b7434812; ?>
<?php unset($__componentOriginal68fd1716d3649640b85d625349a99a37b7434812); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\PalLancer Laravel 02\pallancer-store\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>