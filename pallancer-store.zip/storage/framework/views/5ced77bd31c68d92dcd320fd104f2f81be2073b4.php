<?php if($paginator->hasPages()): ?>
<div class="d-flex justify-content-between">
    <nav>
        <ul class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true">
                    <span class="page-link"><?php echo app('translator')->get('pagination.previous'); ?></span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo app('translator')->get('pagination.previous'); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo app('translator')->get('pagination.next'); ?></a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true">
                    <span class="page-link"><?php echo app('translator')->get('pagination.next'); ?></span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
    <p class="text-sm text-gray-700 leading-5">
        <?php echo __('Showing'); ?>

        <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
        <?php echo __('to'); ?>

        <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
        <?php echo __('results'); ?>

    </p>
</div>
<?php endif; ?>
<?php /**PATH E:\PalLancer Laravel 02\pallancer-store\resources\views/vendor/pagination/simple-bootstrap-4.blade.php ENDPATH**/ ?>