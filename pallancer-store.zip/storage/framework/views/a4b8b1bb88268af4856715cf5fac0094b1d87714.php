<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
    <div style="">
        <p>Hello, <?php echo e($notifiable->name); ?>,</p>
        <p>A new order has created</p>
        <table>
        
        </table>
    </div>
</body>
</html><?php /**PATH E:\PalLancer Laravel 02\pallancer-store\resources\views/mails/invoice.blade.php ENDPATH**/ ?>