<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    <header class="py-2 bg-dark text-white mb-4">
        <div class="container">
            <div class="d-flex">
                <h1 class="h3"><?php echo e(config('app.name')); ?></h1>

                
                <?php if(auth()->guard('web')->check()): ?>
                <div class="ms-auto">
                    Hi, <?php echo e(Auth::guard('web')->user()->name); ?>

                    | <a href="#" onclick="document.getElementById('logout').submit()">Logout</a>
                    <form id="logout" class="d-none" action="<?php echo e(route('logout', 'web')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="container">
        <div class="row">
            <aside class="col-md-3">
                <h4>Navigation Menu</h4>
                <nav>
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item"><a href="" class="nav-link">Dashboard</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('admin.categories.index')); ?>" class="nav-link <?php if(request()->routeIs('admin.categories.*')): ?> active <?php endif; ?>">Categories</a></li>
                        <li class="nav-item"><a href="" class="nav-link">Products</a></li>
                    </ul>
                </nav>
            </aside>
            <main class="col-md-9">
                <div class="mb-4">
                    <h3 class="text-primary"><?php echo e($title ?? 'Default Title'); ?></h3>
                    <h5 class="text-primary"><?php echo e($subtitle ?? ''); ?></h5>
                </div>
                
                <?php echo e($slot); ?>

            </main>
        </div>
    </div>

    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script>
    window.UserId = "<?php echo e(Auth::id()); ?>";
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>

</body>

</html><?php /**PATH E:\PalLancer Laravel 02\pallancer-store\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>