<?php echo e($slot); ?>

<?php /**PATH E:\PalLancer Laravel 02\pallancer-store\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>